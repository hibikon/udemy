"""used in import.py
"""


from package.tools import utils
# from ..tools import utils


def sing():
    return 'dawerafwad'

def cry():
    return utils.say_twice('csdafgasdfvaf')