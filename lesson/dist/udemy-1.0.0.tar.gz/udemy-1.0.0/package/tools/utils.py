# used in import.py

def say_twice(word):
    return (word + '!') * 2